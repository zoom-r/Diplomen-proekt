/**
 * Модел на запис за заместващ час.
 */
class SubstitutionEntry {
    constructor(
      public date: string,
      public time: number,
      public group: string,
      public shift: 'first' | 'second',
      public room: string | null,
      public absentTeacher: { id: string, name: string, position: string }, // може да няма отсъстващ учител
      public substitute?: { id: string, name: string, position: string } // може да няма заместник
    ) {}
  
    // static createFromResultSet(rs: GoogleAppsScript.JDBC.JdbcResultSet): SubstitutionEntry {
    //   return new SubstitutionEntry(
    //     rs.getString('time'),
    //     rs.getString('group'),
    //     rs.getString('shift') as 'first' | 'second',
    //     rs.getString('room'),
    //     JSON.parse(rs.getString('absentTeacher') || '{}'),
    //     rs.getString('substitute') ? JSON.parse(rs.getString('substitute')) : undefined
    //   );
    // }
  }
  